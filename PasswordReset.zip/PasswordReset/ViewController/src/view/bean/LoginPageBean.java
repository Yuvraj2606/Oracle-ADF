package view.bean;

import java.util.Date;

import javax.el.ELContext;

import javax.el.ExpressionFactory;

import javax.el.ValueExpression;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import model.service.PasswordResetAMImpl;

import oracle.adf.view.rich.component.rich.input.RichInputText;

import oracle.jbo.Row;
import oracle.jbo.ViewObject;

public class LoginPageBean {
    private RichInputText USERNAME;
    private RichInputText PASSWORD;
    public LoginPageBean() {
    }
    public static Object evaluateEL(String el) {

           FacesContext facesContext = FacesContext.getCurrentInstance();
           ELContext elContext = facesContext.getELContext();
           ExpressionFactory ef = facesContext.getApplication().getExpressionFactory();
           ValueExpression exp = ef.createValueExpression(elContext, el, Object.class);

           return exp.getValue(elContext);
       }

       protected PasswordResetAMImpl getAm() {

           return (PasswordResetAMImpl) evaluateEL("#{data.PasswordResetAMDataControl.dataProvider}");
       }

    public void onClcikLoginButton(ActionEvent actionEvent) {
        // Add event code here...
        try {
                String username = USERNAME.getValue() != null ? USERNAME.getValue().toString() : "";
                String password = PASSWORD.getValue() != null ? PASSWORD.getValue().toString() : "";

                ViewObject loginVO = (ViewObject) getAm().getUserDataQueryBasedVO1();

                loginVO.setNamedWhereClauseParam("bindUsername", username);
                loginVO.executeQuery();
                int countrow = (int) loginVO.getEstimatedRowCount();
                System.out.println("Row count is------>" + loginVO.getEstimatedRowCount());

                System.out.println("---------------------->" + loginVO.getQuery());
                Row r = (Row) loginVO.first();
                System.out.println("----------------->" + loginVO.getCurrentRow());
                System.out.println("------------------------>" + loginVO.first());

                if (countrow > 0) {
                    String Uname = (String) r.getAttribute("UserName");
                    String Upassword = (String) r.getAttribute("Password");
                    Date UPasswordValidUpto = (Date) r.getAttribute("PasswordValidUpto");

                    if (Uname.equals(username) && Upassword.equals(password)) {
                        // Check if the current system date is less than or equal to UPasswordValidUpto
                        Date currentDate = new Date();
                        if (currentDate.compareTo(UPasswordValidUpto) <= 0) {
                            // Navigate to the desired page
                            FacesContext.getCurrentInstance().getApplication().getNavigationHandler()
                                .handleNavigation(FacesContext.getCurrentInstance(), null, "ForViewTable");
                        } else {
                            // Password validity has expired
                            FacesContext facesContext = FacesContext.getCurrentInstance();
                            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                "Password Expired",
                                "Your password is no longer valid. Please contact support.");
                            facesContext.addMessage(null, message);
                        }
                    } else {
                        // Username or password is incorrect
                        FacesContext facesContext = FacesContext.getCurrentInstance();
                        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                            "Invalid Username or Password",
                            "Invalid Username or Password");
                        facesContext.addMessage(null, message);
                    }
                } else {
                    // Username does not exist
                    FacesContext facesContext = FacesContext.getCurrentInstance();
                    FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                        "Invalid Username or Password",
                        "Invalid Username or Password");
                    facesContext.addMessage(null, message);
                }
            } catch (Exception e) {
                e.printStackTrace();
            } 
                setUSERNAME(null);
                setPASSWORD(null);   
    }

    public void setUSERNAME(RichInputText USERNAME) {
        this.USERNAME = USERNAME;
    }

    public RichInputText getUSERNAME() {
        return USERNAME;
    }

    public void setPASSWORD(RichInputText PASSWORD) {
        this.PASSWORD = PASSWORD;
    }

    public RichInputText getPASSWORD() {
        return PASSWORD;
    }
}
