package view.bean;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import oracle.adf.model.BindingContext;
import oracle.adf.model.OperationBinding;
import oracle.adf.model.binding.DCBindingContainer;

public class InsertPageBean {
    public InsertPageBean() {
    }

    public void onClickSaveButton(ActionEvent actionEvent) {
        // Add event code here...
        try {
            // Get the binding container
            DCBindingContainer bindings = getBindings();

            // Get and execute the commit operation
            OperationBinding commit = (OperationBinding) bindings.getOperationBinding("Commit");
            if (commit != null) {
                commit.execute();
                FacesContext facesContext = FacesContext.getCurrentInstance();
                facesContext.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Success", "Your data has been saved."));
            
            }
        } catch (Exception e) {
            e.printStackTrace();
            FacesContext facesContext = FacesContext.getCurrentInstance();
            facesContext.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "An unexpected error occurred."));
        }
    }
    private DCBindingContainer getBindings() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        BindingContext bindingContext = BindingContext.getCurrent();
        return (DCBindingContainer) bindingContext.getCurrentBindingsEntry();
    }
}


