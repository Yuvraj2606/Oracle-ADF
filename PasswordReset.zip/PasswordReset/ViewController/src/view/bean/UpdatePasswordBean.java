package view.bean;

import java.sql.Timestamp;

import java.util.Calendar;
import java.util.Date;

import javax.el.ELContext;
import javax.el.ExpressionFactory;
import javax.el.ValueExpression;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import model.service.PasswordResetAMImpl;

import oracle.adf.view.rich.component.rich.input.RichInputText;

import oracle.jbo.Row;
import oracle.jbo.ViewCriteria;
import oracle.jbo.ViewObject;
import oracle.jbo.domain.Number;


public class UpdatePasswordBean {
    private RichInputText USERID;
    private RichInputText CURRENTPASSWORD;
    private RichInputText NEWPASSWORD;

    public UpdatePasswordBean() {
    }

    public static Object evaluateEL(String el) {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        ELContext elContext = facesContext.getELContext();
        ExpressionFactory ef = facesContext.getApplication().getExpressionFactory();
        ValueExpression exp = ef.createValueExpression(elContext, el, Object.class);
        return exp.getValue(elContext);
    }

    protected PasswordResetAMImpl getAm() {
        return (PasswordResetAMImpl) evaluateEL("#{data.PasswordResetAMDataControl.dataProvider}");
    }

    public void onClickUpdateButtonAL(ActionEvent actionEvent) {
        String userIdStr = USERID.getValue() != null ? USERID.getValue().toString() : null;
        String currentPassword = CURRENTPASSWORD.getValue() != null ? CURRENTPASSWORD.getValue().toString() : "";
        String newPassword = NEWPASSWORD.getValue() != null ? NEWPASSWORD.getValue().toString() : "";
        
      Integer userId = userIdStr != null ? Integer.valueOf(userIdStr) : null;
        
        System.out.println("Entered UserId----------->"+userId);
        System.out.println("Enter Current Password ------->"+currentPassword);
        System.out.println("Enter New Password------>"+newPassword);
        
        ViewObject userVO = (ViewObject) getAm().getUserIDEOBasedVO1();
            ViewCriteria vc = userVO.getViewCriteriaManager().getViewCriteria("UserIDEOBasedVOCriteria");
                  userVO.applyViewCriteria(vc);
                 userVO.setNamedWhereClauseParam("bindUserid", userId);
                 userVO.executeQuery();
        int countrow = (int) userVO.getEstimatedRowCount();
        System.out.println("Row count is------>" + userVO.getEstimatedRowCount());    
            Row r = (Row) userVO.first();
            if (countrow > 0) {
                Number Uid = (Number) r.getAttribute("UserId");
                System.out.println("UserId ------>"+Uid);
                 
                if (Uid.equals(userId)){
                        r.setAttribute("Password", newPassword);
                                 
                                   

                                   // Update PasswordValidUpto attribute to current system date plus 2 days
                                   Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
                                   long twoDaysInMillis = 2 * 24 * 60 * 60 * 1000; // 2 days in milliseconds
                                   Timestamp passwordValidUpto = new Timestamp(currentTimestamp.getTime() + twoDaysInMillis);
                                   r.setAttribute("PasswordValidUpto", passwordValidUpto);
                                   r.setAttribute("LastUpdatedDate", currentTimestamp);
                                   // Commit changes to database
                                   getAm().getDBTransaction().commit();
                                   FacesContext facesContext = FacesContext.getCurrentInstance();
                                   FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
                                       "Password updated successfully.",
                                       "Password updated successfully.");
                                   facesContext.addMessage(null, message);
                               } else {
                                   FacesContext facesContext = FacesContext.getCurrentInstance();
                                   FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                       "Invalid User ID.",
                                       "Invalid User ID.");
                                   facesContext.addMessage(null, message);
                               }
                    }
            }

    public void setUSERID(RichInputText USERID) {
        this.USERID = USERID;
    }

    public RichInputText getUSERID() {
        return USERID;
    }

    public void setCURRENTPASSWORD(RichInputText CURRENTPASSWORD) {
        this.CURRENTPASSWORD = CURRENTPASSWORD;
    }

    public RichInputText getCURRENTPASSWORD() {
        return CURRENTPASSWORD;
    }

    public void setNEWPASSWORD(RichInputText NEWPASSWORD) {
        this.NEWPASSWORD = NEWPASSWORD;
    }

    public RichInputText getNEWPASSWORD() {
        return NEWPASSWORD;
    }
}
 
