package view.bean;

import javax.el.ELContext;

import javax.el.ExpressionFactory;

import javax.el.ValueExpression;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import model.service.SearchButtonPopUpAMImpl;

import oracle.jbo.ViewObject;
import oracle.jbo.domain.Char;
import oracle.jbo.domain.Number;

public class ApplicationBean {
    public ApplicationBean() {
    }
    
    public static Object evaluateEL(String el) {

          FacesContext facesContext = FacesContext.getCurrentInstance();
          ELContext elContext = facesContext.getELContext();
          ExpressionFactory ef = facesContext.getApplication().getExpressionFactory();
          ValueExpression exp = ef.createValueExpression(elContext, el, Object.class);

          return exp.getValue(elContext);
      }

      protected SearchButtonPopUpAMImpl getAm() {
          return (SearchButtonPopUpAMImpl) evaluateEL("#{data.SearchButtonPopUpAMDataControl.dataProvider}");
      }

    public void onClickSearchButtonAL(ActionEvent actionEvent) {
        try {
           // Retrieve the TransEmployee ViewObject
           ViewObject transEmpVO = getAm().getTransVO1();

           String state = (String) transEmpVO.getCurrentRow().getAttribute("TransState");
           System.out.println("State --------------------->" + state);

           // Retrieve the Employee ViewObject
           ViewObject employeeVO = getAm().getEmployeeDetailVO1();

           // Set the parameters for the query
           System.out.println("Before bind variable");
           employeeVO.setNamedWhereClauseParam("bind_state", state);
            System.out.println("After bind variable");

           // Execute the query to refresh the data in the table
           employeeVO.executeQuery();
            System.out.println("After bind variable");


         
        } catch (Exception e) {
            // TODO: Add catch code
            e.printStackTrace();
        }
        // Add event code here...
    }
}
