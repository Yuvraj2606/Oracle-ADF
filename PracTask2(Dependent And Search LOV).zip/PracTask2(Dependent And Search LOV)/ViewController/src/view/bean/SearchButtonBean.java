package view.bean;

import javax.el.ELContext;
import javax.el.ExpressionFactory;

import javax.el.ValueExpression;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import model.service.PracTask2AMImpl;

import oracle.jbo.Row;
import oracle.jbo.ViewObject;



public class SearchButtonBean {
    public SearchButtonBean() {
    }
    public static Object evaluateEL(String el) {

             FacesContext facesContext = FacesContext.getCurrentInstance();
                 ELContext elContext = facesContext.getELContext();
                 ExpressionFactory ef = facesContext.getApplication().getExpressionFactory();
                 ValueExpression exp = ef.createValueExpression(elContext, el, Object.class);
                 
                 return exp.getValue(elContext);
         }

         public PracTask2AMImpl getAm() {

             return (PracTask2AMImpl) evaluateEL("#{data.PracTask2AMDataControl.dataProvider}");
         }

    public void onCLickSearchButtonAL(ActionEvent actionEvent) {
        // Add event code here...
        try {
           
           ViewObject transCountryVO = getAm().getTransTableVO1();
           Row countryRow = transCountryVO.getCurrentRow();

           // Check if a row is currently selected
           if (countryRow != null) {
           oracle.jbo.domain.Number countryId = (oracle.jbo.domain.Number) countryRow.getAttribute("TransCountryId");
           System.out.println("Country Id is -----> " + countryId);
           oracle.jbo.domain.Number stateId = (oracle.jbo.domain.Number) countryRow.getAttribute("TransStateId");
           System.out.println("State Id is -----> " + stateId);
           oracle.jbo.domain.Number cityId = (oracle.jbo.domain.Number) countryRow.getAttribute("TransCityId");
           System.out.println("City Id is -----> " + cityId);

           ViewObject employeeVO = getAm().getEmployeeVO1();
           employeeVO.setNamedWhereClauseParam("BINDEMP_COUNTRY_ID", countryId);
           employeeVO.setNamedWhereClauseParam("BINDEMP_STATE_ID", stateId);
           employeeVO.setNamedWhereClauseParam("BINDEMP_CITY_ID", cityId);
           employeeVO.executeQuery();
           } else {
           System.out.println("No current row in TransTableVO1");
           // Handle the case where no row is selected if needed
           }
       } catch (Exception e) {
            // TODO: Add catch code
            e.printStackTrace();
        }
    }
}
