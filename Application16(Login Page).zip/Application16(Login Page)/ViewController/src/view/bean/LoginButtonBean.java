package view.bean;

import javax.el.ELContext;

import javax.el.ExpressionFactory;

import javax.el.ValueExpression;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import model.service.Application16AMImpl;

import oracle.adf.view.rich.component.rich.input.RichInputText;

import oracle.jbo.Row;
import oracle.jbo.ViewObject;

public class LoginButtonBean {
    private RichInputText USERNAME;
    private RichInputText PASSWORD;
        
    public LoginButtonBean() {
    }
    public static Object evaluateEL(String el) {

           FacesContext facesContext = FacesContext.getCurrentInstance();
           ELContext elContext = facesContext.getELContext();
           ExpressionFactory ef = facesContext.getApplication().getExpressionFactory();
           ValueExpression exp = ef.createValueExpression(elContext, el, Object.class);

           return exp.getValue(elContext);
       }

       protected Application16AMImpl getAm() {
           return (Application16AMImpl) evaluateEL("#{data.Application16AMDataControl.dataProvider}");
       }
    public void onClickLoginAL(ActionEvent actionEvent) {
        try {

            String username = USERNAME.getValue() != null ? USERNAME.getValue().toString() : "";
            String password = PASSWORD.getValue() != null ? PASSWORD.getValue().toString() : "";

            ViewObject loginVO = (ViewObject) getAm().getLoginQryVO1();
    
            loginVO.setNamedWhereClauseParam("bind", username);
            loginVO.executeQuery();
            int countrow=(int)   loginVO.getEstimatedRowCount();
            System.out.println("Row count is------>"+loginVO.getEstimatedRowCount());
            
            System.out.println("---------------------->"+loginVO.getQuery());
            Row r = (Row) loginVO.first();
            System.out.println("----------------->"+loginVO.getCurrentRow());
            System.out.println("------------------------>"+loginVO.first());
            if(countrow>0){
            String uname = (String) r.getAttribute("Username");
            String Upassword = (String) r.getAttribute("Password");

            if (uname.equals(username.toUpperCase())  && Upassword.equals(password)) {
                FacesContext.getCurrentInstance().getApplication().getNavigationHandler()
                    .handleNavigation(FacesContext.getCurrentInstance(), null, "CallButtonsPage");
            } 

            }
            else{
                System.out.println("--------------------------------------------------------------------");
                FacesContext facesContext = FacesContext.getCurrentInstance();
                FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, 
                    "Invalid Username or Password", 
                    "Invalid Username or Password");
                facesContext.addMessage(null, message);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        setUSERNAME(null);
        setPASSWORD(null);
    }


    public void setUSERNAME(RichInputText USERNAME) {
        this.USERNAME = USERNAME;
    }

    public RichInputText getUSERNAME() {
        return USERNAME;
    }

    public void setPASSWORD(RichInputText PASSWORD) {
        this.PASSWORD = PASSWORD;
    }

    public RichInputText getPASSWORD() {
        return PASSWORD;
    }
}
