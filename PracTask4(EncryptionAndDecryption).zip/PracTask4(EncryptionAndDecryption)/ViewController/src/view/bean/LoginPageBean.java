package view.bean;

import javax.el.ELContext;
import javax.el.ExpressionFactory;
import javax.el.ValueExpression;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import model.service.PracTask4AMImpl;
import oracle.adf.view.rich.component.rich.input.RichInputText;
import oracle.jbo.Row;
import oracle.jbo.ViewObject;
import javax.crypto.Cipher;  
import javax.crypto.SecretKey;  
import javax.crypto.SecretKeyFactory;  
import javax.crypto.spec.IvParameterSpec;  
import javax.crypto.spec.PBEKeySpec;  
import javax.crypto.spec.SecretKeySpec;  
import java.nio.charset.StandardCharsets;  
import java.security.InvalidAlgorithmParameterException;  
import java.security.InvalidKeyException;  
import java.security.NoSuchAlgorithmException;  
import java.security.spec.InvalidKeySpecException;  
import java.security.spec.KeySpec;  
import java.util.Base64;  
import javax.crypto.BadPaddingException;  
import javax.crypto.IllegalBlockSizeException;  
import javax.crypto.NoSuchPaddingException;

public class LoginPageBean {
    private RichInputText USERNAME;
    private RichInputText PASSWORD;
    private static final String SECRET_KEY = "123456789";
    private static final String SALTVALUE = "abcdefg";

    public LoginPageBean() {
    }

    public static Object evaluateEL(String el) {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        ELContext elContext = facesContext.getELContext();
        ExpressionFactory ef = facesContext.getApplication().getExpressionFactory();
        ValueExpression exp = ef.createValueExpression(elContext, el, Object.class);

        return exp.getValue(elContext);
    }

    protected PracTask4AMImpl getAm() {
        return (PracTask4AMImpl) evaluateEL("#{data.PracTask4AMDataControl.dataProvider}");
    }

    private String decrypt(String strToDecrypt) {
        try {
            byte[] iv = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
            IvParameterSpec ivspec = new IvParameterSpec(iv);
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            KeySpec spec = new PBEKeySpec(SECRET_KEY.toCharArray(), SALTVALUE.getBytes(), 65536, 256);
            SecretKey tmp = factory.generateSecret(spec);
            SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
            cipher.init(Cipher.DECRYPT_MODE, secretKey, ivspec);
            return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
        } catch (InvalidAlgorithmParameterException | InvalidKeyException | NoSuchAlgorithmException | InvalidKeySpecException | BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException e) {
            System.out.println("Error occurred during decryption: " + e.toString());
        }
        return null;
    }

//    private String encrypt(String strToEncrypt) {
//        try {
//            byte[] iv = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
//            IvParameterSpec ivspec = new IvParameterSpec(iv);
//            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
//            KeySpec spec = new PBEKeySpec(SECRET_KEY.toCharArray(), SALTVALUE.getBytes(), 65536, 256);
//            SecretKey tmp = factory.generateSecret(spec);
//            SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");
//            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
//            cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivspec);
//            return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes(StandardCharsets.UTF_8)));
//        } catch (InvalidAlgorithmParameterException | InvalidKeyException | NoSuchAlgorithmException | InvalidKeySpecException | BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException e) {
//            System.out.println("Error occurred during encryption: " + e.toString());
//        }
//        return null;
//    }

    public void onClickLoginButton(ActionEvent actionEvent) {
        try {
            String username = USERNAME.getValue() != null ? USERNAME.getValue().toString() : "";
            String password = PASSWORD.getValue() != null ? PASSWORD.getValue().toString() : "";

            ViewObject loginVO = (ViewObject) getAm().getLoginDetailQueryBasedVO1();
            loginVO.setNamedWhereClauseParam("bindUsername", username);
            loginVO.executeQuery();
            int countrow = (int) loginVO.getEstimatedRowCount();

            if (countrow > 0) {
                Row r = (Row) loginVO.first();
                String uname = (String) r.getAttribute("Username");
                String encryptedPassword = (String) r.getAttribute("PaswordHash");
                
                

                // Decrypt the encrypted password using the AES method
                String decryptedPassword = decrypt(encryptedPassword);

                if (uname.equals(username) && decryptedPassword.equals(password)) {
                    FacesContext.getCurrentInstance().getApplication().getNavigationHandler()
                        .handleNavigation(FacesContext.getCurrentInstance(), null, "ForViewData");
                    System.out.println("Uname----------" + uname);
                    System.out.println("Encrypted Password--------->"+encryptedPassword);
                    System.out.println("Decrypted Password-------" + decryptedPassword);
                } else {
                    FacesContext facesContext = FacesContext.getCurrentInstance();
                    FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                        "Invalid Username or Password",
                        "Invalid Username or Password");
                    facesContext.addMessage(null, message);
                }
            } else {
                FacesContext facesContext = FacesContext.getCurrentInstance();
                FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                    "Invalid Username or Password",
                    "Invalid Username or Password");
                facesContext.addMessage(null, message);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        setUSERNAME(null);
        setPASSWORD(null);
    }

    public void setUSERNAME(RichInputText USERNAME) {
        this.USERNAME = USERNAME;
    }

    public RichInputText getUSERNAME() {
        return USERNAME;
    }

    public void setPASSWORD(RichInputText PASSWORD) {
        this.PASSWORD = PASSWORD;
    }

    public RichInputText getPASSWORD() {
        return PASSWORD;
    }
}
