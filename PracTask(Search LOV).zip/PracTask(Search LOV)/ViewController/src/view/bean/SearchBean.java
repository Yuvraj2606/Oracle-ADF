package view.bean;

import javax.el.ELContext;
import oracle.jbo.domain.Number;
import javax.el.ExpressionFactory;

import javax.el.ValueExpression;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import model.services.PracTaskAMImpl;

import oracle.jbo.Row;
import oracle.jbo.ViewObject;

public class SearchBean {
    public SearchBean() {
    }
    public static Object evaluateEL(String el) {

             FacesContext facesContext = FacesContext.getCurrentInstance();
             ELContext elContext = facesContext.getELContext();
             ExpressionFactory ef = facesContext.getApplication().getExpressionFactory();
             ValueExpression exp = ef.createValueExpression(elContext, el, Object.class);

             return exp.getValue(elContext);
         }

         protected PracTaskAMImpl getAm() {

             return (PracTaskAMImpl) evaluateEL("#{data.PracTaskAMDataControl.dataProvider}");
         }

    public void onClickSearchButton(ActionEvent actionEvent) {
        // Add event code here...
        try {
            

            
//            ViewObject transCountryVO = (ViewObject) getAm().getTransTableVO1();
//                Row countryRow = (Row) transCountryVO.getCurrentRow();
//           System.out.println("---------------------->"+countryRow.getAttributeCount());
//            System.out.println("----------------------"+transCountryVO.getEstimatedRowCount());
////            transCountryVO.executeQuery();
//                 oracle.jbo.domain.Number CountryId = (oracle.jbo.domain.Number)countryRow.getAttribute("TransCountryId");
//           System.out.println("Country Id is----->"+CountryId);
//           ViewObject EmployeeVO = getAm().getEmployeeVO1();
//               EmployeeVO.setNamedWhereClauseParam("BINDEMP_COUNTRY_ID", CountryId);
//               EmployeeVO.executeQuery();
            
            
            
            ViewObject transCountryVO = getAm().getTransTableVO1();
    Row countryRow = transCountryVO.getCurrentRow();

    // Check if a row is currently selected
    if (countryRow != null) {
        oracle.jbo.domain.Number countryId = (oracle.jbo.domain.Number) countryRow.getAttribute("TransCountryId");
        System.out.println("Country Id is -----> " + countryId);
        oracle.jbo.domain.Number stateId = (oracle.jbo.domain.Number) countryRow.getAttribute("TransStateId");
        System.out.println("State Id is -----> " + stateId);
        oracle.jbo.domain.Number cityId = (oracle.jbo.domain.Number) countryRow.getAttribute("TransCityId");
        System.out.println("City Id is -----> " + cityId);

        ViewObject employeeVO = getAm().getEmployeeVO1();
        employeeVO.setNamedWhereClauseParam("BINDEMP_COUNTRY_ID", countryId);
        employeeVO.setNamedWhereClauseParam("BINDEMP_STATE_ID", stateId);
        employeeVO.setNamedWhereClauseParam("BINDEMP_CITY_ID", cityId);
        employeeVO.executeQuery();
    } else {
        System.out.println("No current row in TransTableVO1");
        // Handle the case where no row is selected if needed
    }
       } catch (Exception e) {
            // TODO: Add catch code
            e.printStackTrace();
        }
    }
}
