package view.bean;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import oracle.adf.model.BindingContext;
import oracle.adf.model.OperationBinding;
import oracle.adf.model.binding.DCBindingContainer;

public class EmployeeBean {
    public EmployeeBean() {
    }

    public void onClickSaveButtonAL(ActionEvent actionEvent) {
        try {
            // Get the current bindings container
            DCBindingContainer bindings = (DCBindingContainer) getBindings();
            
            // Find and execute the Commit operation binding
            OperationBinding commit = (OperationBinding) bindings.getOperationBinding("Commit");
            if (commit != null) {
                commit.execute();
                
                // Check for errors after executing the commit operation
                if (!commit.getErrors().isEmpty()) {
                    // If there are errors, show an error message
                    FacesContext facesContext = FacesContext.getCurrentInstance();
                    facesContext.addMessage(null, new javax.faces.application.FacesMessage(
                        javax.faces.application.FacesMessage.SEVERITY_ERROR,
                        "Save failed",
                        "There was an issue saving the data."
                    ));
                } else {
                    // If there are no errors, show a success message
                    FacesContext facesContext = FacesContext.getCurrentInstance();
                    facesContext.addMessage(null, new javax.faces.application.FacesMessage(
                        javax.faces.application.FacesMessage.SEVERITY_INFO,
                        "Save successful",
                        "The data has been saved successfully."
                    ));
                }
            }
        } catch (Exception e) {
            // Handle exceptions and show a generic error message
            e.printStackTrace();
            FacesContext facesContext = FacesContext.getCurrentInstance();
            facesContext.addMessage(null, new javax.faces.application.FacesMessage(
                javax.faces.application.FacesMessage.SEVERITY_ERROR,
                "Save failed",
                "An unexpected error occurred while saving the data."
            ));
        }
    }

    private DCBindingContainer getBindings() {
        // Retrieve the current binding container from the FacesContext
        FacesContext facesContext = FacesContext.getCurrentInstance();
        BindingContext bindingContext = BindingContext.getCurrent();
        return (DCBindingContainer) bindingContext.getCurrentBindingsEntry();
    }
}
