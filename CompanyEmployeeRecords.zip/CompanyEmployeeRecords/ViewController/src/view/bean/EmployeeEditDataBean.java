package view.bean;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import oracle.adf.model.BindingContext;
import oracle.adf.model.OperationBinding;
import oracle.adf.model.binding.DCBindingContainer;

public class EmployeeEditDataBean {

    private boolean disabledFields = true;  // Fields are initially disabled

    public EmployeeEditDataBean() {
    }

    // Getter and setter for disabledFields
    public boolean isDisabledFields() {
        return disabledFields;
    }

    public void setDisabledFields(boolean disabledField) {
        this.disabledFields = disabledField;
    }

    public void onClickEditButtonAL(ActionEvent actionEvent) {
       enableInputs();
    }
    public void disableInputs() {
        disabledFields = true; 
    }
    
    public void enableInputs() {
        disabledFields = false; 
    }

    public void onClickSaveButtonAL(ActionEvent actionEvent) {
        // Add event code here...
        try {
            // Get the current bindings container
            DCBindingContainer bindings = (DCBindingContainer) getBindings();
            
            // Find and execute the Commit operation binding
            OperationBinding commit = (OperationBinding) bindings.getOperationBinding("Commit");
            if (commit != null) {
                commit.execute();
                
                // Check for errors after executing the commit operation
                if (!commit.getErrors().isEmpty()) {
                    // If there are errors, show an error message
                    FacesContext facesContext = FacesContext.getCurrentInstance();
                    facesContext.addMessage(null, new javax.faces.application.FacesMessage(
                        javax.faces.application.FacesMessage.SEVERITY_ERROR,
                        "Save failed",
                        "There was an issue saving the data."
                    ));
                } else {
                    // If there are no errors, show a success message
                    FacesContext facesContext = FacesContext.getCurrentInstance();
                    facesContext.addMessage(null, new javax.faces.application.FacesMessage(
                        javax.faces.application.FacesMessage.SEVERITY_INFO,
                        "Save successful",
                        "Changes Saved successful."
                    ));
                }
            }
            
        } catch (Exception e) {
            // Handle exceptions and show a generic error message
            e.printStackTrace();
            FacesContext facesContext = FacesContext.getCurrentInstance();
            facesContext.addMessage(null, new javax.faces.application.FacesMessage(
                javax.faces.application.FacesMessage.SEVERITY_ERROR,
                "Save failed",
                "An unexpected error occurred while saving the data."
            ));
        }
        disableInputs();  
    }
    private DCBindingContainer getBindings() {
        // Retrieve the current binding container from the FacesContext
        FacesContext facesContext = FacesContext.getCurrentInstance();
        BindingContext bindingContext = BindingContext.getCurrent();
        return (DCBindingContainer) bindingContext.getCurrentBindingsEntry();
    }
}
