package view.bean;

import javax.el.ELContext;

import javax.el.ExpressionFactory;

import javax.el.ValueExpression;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import model.service.CompanyEmployeeRecordsAMImpl;

import oracle.adf.model.BindingContext;
import oracle.adf.model.OperationBinding;
import oracle.adf.model.binding.DCBindingContainer;

import oracle.jbo.Row;
import oracle.jbo.ViewCriteria;
import oracle.jbo.ViewObject;
import oracle.jbo.domain.Number;
import oracle.jbo.domain.Char;

public class EmployeeRecordBean {
    
    public EmployeeRecordBean() {
    }
    
    public static Object evaluateEL(String el) {

            FacesContext facesContext = FacesContext.getCurrentInstance();
            ELContext elContext = facesContext.getELContext();
            ExpressionFactory ef = facesContext.getApplication().getExpressionFactory();
            ValueExpression exp = ef.createValueExpression(elContext, el, Object.class);

            return exp.getValue(elContext);
        }

        protected CompanyEmployeeRecordsAMImpl getAm() {
            return (CompanyEmployeeRecordsAMImpl) evaluateEL("#{data.CompanyEmployeeRecordsAMDataControl.dataProvider}");
        }

    public void onClickSearchButtonAL(ActionEvent actionEvent) {
        // Add event code here...
        try {
           // Retrieve the TransEmployee ViewObject
           ViewObject transEmpVO = getAm().getTransEmployeeVO1();

           // Get the search criteria from the input fields
           String city = (String) transEmpVO.getCurrentRow().getAttribute("TransCity");
           System.out.println("City ----------------->" + city);

           Char countryId = (Char) transEmpVO.getCurrentRow().getAttribute("TransCountryId");
           System.out.println("Country Id ----------------------->" + countryId);

           Number departmentId = (Number) transEmpVO.getCurrentRow().getAttribute("TransDepartmentId");
           System.out.println("Department Id --------------------->" + departmentId);

           String empName = (String) transEmpVO.getCurrentRow().getAttribute("TransEmployeeName");
           System.out.println("Employee Name ----------------------->" + empName);

           String jobId = (String) transEmpVO.getCurrentRow().getAttribute("TransJobId");
           System.out.println("Job Id --------------------->" + jobId);

           String state = (String) transEmpVO.getCurrentRow().getAttribute("TransState");
           System.out.println("State --------------------->" + state);

           // Retrieve the Employee ViewObject
           ViewObject employeeVO = getAm().getEmployeeDetailsVO1();

           // Set the parameters for the query
           employeeVO.setNamedWhereClauseParam("BINDCITY", city);
           employeeVO.setNamedWhereClauseParam("BINDCOUNTRYID", countryId);
           employeeVO.setNamedWhereClauseParam("BINDDEPARTMENTID", departmentId);
           employeeVO.setNamedWhereClauseParam("BINDEMPNAME", empName);
           employeeVO.setNamedWhereClauseParam("BINDJOBID", jobId);
           employeeVO.setNamedWhereClauseParam("BINDSTATE", state);

           // Execute the query to refresh the data in the table
           employeeVO.executeQuery();

         
       } catch (Exception e) {
            // TODO: Add catch code
            e.printStackTrace();
        }
    }

    public void onClickResetButtonAL(ActionEvent actionEvent) {
        try {
           ViewObject transEmpVO = getAm().getTransEmployeeVO1();

                      // Clear all the search fields
                      transEmpVO.getCurrentRow().setAttribute("TransCity", null);
                      transEmpVO.getCurrentRow().setAttribute("TransCountryId", null);
                      transEmpVO.getCurrentRow().setAttribute("TransDepartmentId", null);
                      transEmpVO.getCurrentRow().setAttribute("TransEmployeeName", null);
                      transEmpVO.getCurrentRow().setAttribute("TransJobId", null);
                      transEmpVO.getCurrentRow().setAttribute("TransState", null);

                      // Optionally, reset the Employee ViewObject query parameters
                      ViewObject employeeVO = getAm().getEmployeeDetailsVO1();
           employeeVO.setNamedWhereClauseParam("BINDCITY", null);
           employeeVO.setNamedWhereClauseParam("BINDCOUNTRYID", null);
           employeeVO.setNamedWhereClauseParam("BINDDEPARTMENTID", null);
           employeeVO.setNamedWhereClauseParam("BINDEMPNAME", null);
           employeeVO.setNamedWhereClauseParam("BINDJOBID", null);
           employeeVO.setNamedWhereClauseParam("BINDSTATE", null); // Clear the where clause to show all records if needed
                      employeeVO.executeQuery(); 
       } catch (Exception e) {
            // TODO: Add catch code
            e.printStackTrace();
        }
        // Add event code here...
    }

    public void onClickLinkAL(ActionEvent actionEvent) {
        // Add event code here...
        
        
        try {
           ViewObject EmpVo = getAm().getEmployeeDetailsVO1();
            Row currentRow = EmpVo.getCurrentRow();
                      Number empId = (Number) currentRow.getAttribute("EmployeeId");
                      System.out.println("Employee Id --------------------->"+empId);
                      
                      ViewObject LinkEmpVO = getAm().getEmployeeEditDataEOBasedVO2();
                      ViewCriteria vc = LinkEmpVO.getViewCriteriaManager().getViewCriteria("EmployeeEditDataEOBasedVOCriteria");
                            LinkEmpVO.applyViewCriteria(vc);
                           LinkEmpVO.setNamedWhereClauseParam("bindEmpId", empId);
                           LinkEmpVO.executeQuery();
          
       } catch (Exception e) {
            // TODO: Add catch code
            e.printStackTrace();
        }
        
    }

    public void onClickSaveButtonAL(ActionEvent actionEvent) {
        // Add event code here...
        try {
            // Get the current bindings container
            DCBindingContainer bindings = (DCBindingContainer) getBindings();
            
            // Find and execute the Commit operation binding
            OperationBinding commit = (OperationBinding) bindings.getOperationBinding("Commit");
            if (commit != null) {
                commit.execute();
                
                // Check for errors after executing the commit operation
                if (!commit.getErrors().isEmpty()) {
                    // If there are errors, show an error message
                    FacesContext facesContext = FacesContext.getCurrentInstance();
                    facesContext.addMessage(null, new javax.faces.application.FacesMessage(
                        javax.faces.application.FacesMessage.SEVERITY_ERROR,
                        "Save failed",
                        "There was an issue saving the data."
                    ));
                } else {
                    // If there are no errors, show a success message
                    FacesContext facesContext = FacesContext.getCurrentInstance();
                    facesContext.addMessage(null, new javax.faces.application.FacesMessage(
                        javax.faces.application.FacesMessage.SEVERITY_INFO,
                        "Save successful",
                        "The data has been saved successfully."
                    ));
                }
            }
        } catch (Exception e) {
            // Handle exceptions and show a generic error message
            e.printStackTrace();
            FacesContext facesContext = FacesContext.getCurrentInstance();
            facesContext.addMessage(null, new javax.faces.application.FacesMessage(
                javax.faces.application.FacesMessage.SEVERITY_ERROR,
                "Save failed",
                "An unexpected error occurred while saving the data."
            ));
        }
    }
    private DCBindingContainer getBindings() {
        // Retrieve the current binding container from the FacesContext
        FacesContext facesContext = FacesContext.getCurrentInstance();
        BindingContext bindingContext = BindingContext.getCurrent();
        return (DCBindingContainer) bindingContext.getCurrentBindingsEntry();
    }
}
