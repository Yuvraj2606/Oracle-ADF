package view.bean;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import oracle.adf.model.BindingContext;
import oracle.adf.model.OperationBinding;
import oracle.adf.model.binding.DCBindingContainer;

import oracle.binding.AttributeBinding;

public class LoginInsertDataBean {
    public LoginInsertDataBean() {
    }

    public void onClickSaveButtonAL(ActionEvent actionEvent) {
        // Add event code here...
        try {
            
           DCBindingContainer bindings = (DCBindingContainer) getBindings();
           
           // Get the password input value
           AttributeBinding passwordAttr = (AttributeBinding) bindings.getControlBinding("PaswordHash");
           String password = (String) passwordAttr.getInputValue();
           
           // Encrypt the password using MD5
           String encryptedPassword = encryptPassword(password);
           
           // Set the encrypted password as the new input value
           passwordAttr.setInputValue(encryptedPassword);
           
           // Find and execute the Commit operation binding
           OperationBinding commit = (OperationBinding) bindings.getOperationBinding("Commit");
           if (commit != null) {
               commit.execute();
               
               // Check for errors after executing the commit operation
               if (!commit.getErrors().isEmpty()) {
                   // If there are errors, show an error message
                   FacesContext facesContext = FacesContext.getCurrentInstance();
                   facesContext.addMessage(null, new javax.faces.application.FacesMessage(
                       javax.faces.application.FacesMessage.SEVERITY_ERROR,
                       "Save failed",
                       "There was an issue saving the data."
                   ));
               } else {
                   // If there are no errors, show a success message
                   FacesContext facesContext = FacesContext.getCurrentInstance();
                   facesContext.addMessage(null, new javax.faces.application.FacesMessage(
                       javax.faces.application.FacesMessage.SEVERITY_INFO,
                       "Save successful",
                       "Username and Password Saved successfully."
                   ));
               }
           }
        } catch (Exception e) {
            // TODO: Add catch code
            e.printStackTrace();
        }
    }
    private String encryptPassword(String password) {
        try {
            MessageDigest m = MessageDigest.getInstance("MD5");
            m.update(password.getBytes());
            byte[] bytes = m.digest();
            StringBuilder s = new StringBuilder();
            for (int i = 0; i < bytes.length; i++) {
                s.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
            }
            return s.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    private DCBindingContainer getBindings() {
        // Retrieve the current binding container from the FacesContext
        FacesContext facesContext = FacesContext.getCurrentInstance();
        BindingContext bindingContext = BindingContext.getCurrent();
        return (DCBindingContainer) bindingContext.getCurrentBindingsEntry();
    }
}
