package view.bean;

import javax.el.ELContext;
import javax.el.ExpressionFactory;
import javax.el.ValueExpression;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import model.service.ButtonPopUpAMImpl;

import oracle.jbo.Row;
import oracle.jbo.ViewCriteria;
import oracle.jbo.ViewObject;
import oracle.jbo.domain.Number;

public class ApplicationBean {
    public ApplicationBean() {
    }
    public static Object evaluateEL(String el) {

            FacesContext facesContext = FacesContext.getCurrentInstance();
            ELContext elContext = facesContext.getELContext();
            ExpressionFactory ef = facesContext.getApplication().getExpressionFactory();
            ValueExpression exp = ef.createValueExpression(elContext, el, Object.class);

            return exp.getValue(elContext);
        }

        protected ButtonPopUpAMImpl getAm() {
            return (ButtonPopUpAMImpl) evaluateEL("#{data.ButtonPopUpAMDataControl.dataProvider}");
        }
    public void onClickLinkAL(ActionEvent actionEvent) {
        // Add event code here...
        try {
           ViewObject EmpVo = getAm().getEmployeeDetailVO1();
            Row currentRow = EmpVo.getCurrentRow();
                      Number empId = (Number) currentRow.getAttribute("EmployeeId");
                      System.out.println("Employee Id --------------------->"+empId);
                      
                      ViewObject LinkEmpVO = getAm().getEmployeeVO1();
                      ViewCriteria vc = LinkEmpVO.getViewCriteriaManager().getViewCriteria("EmployeeVOCriteria");
                            LinkEmpVO.applyViewCriteria(vc);
                           LinkEmpVO.setNamedWhereClauseParam("bindEmpId", empId);
                           LinkEmpVO.executeQuery();
          
        } catch (Exception e) {
            // TODO: Add catch code
            e.printStackTrace();
        }
        
        
    }
}
