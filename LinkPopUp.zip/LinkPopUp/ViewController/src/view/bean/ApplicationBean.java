package view.bean;

import javax.el.ELContext;
import javax.el.ExpressionFactory;
import javax.el.ValueExpression;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import model.service.ButtonPopUpAMImpl;

import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.model.BindingContext;
import oracle.binding.BindingContainer;

import oracle.jbo.Row;
import oracle.jbo.ViewCriteria;
import oracle.jbo.ViewObject;
import oracle.jbo.domain.Number;

public class ApplicationBean {
    private String selectedRowKey;

    public ApplicationBean() {
    }

    public static Object evaluateEL(String el) {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        ELContext elContext = facesContext.getELContext();
        ExpressionFactory ef = facesContext.getApplication().getExpressionFactory();
        ValueExpression exp = ef.createValueExpression(elContext, el, Object.class);
        return exp.getValue(elContext);
    }

    protected ButtonPopUpAMImpl getAm() {
        return (ButtonPopUpAMImpl) evaluateEL("#{data.ButtonPopUpAMDataControl.dataProvider}");
    }

    public void onClickLinkAL(ActionEvent actionEvent) {
        try {
            DCIteratorBinding iterator = getIteratorBinding("EmployeeDetailVO1Iterator");

            // This was the source of the NullPointerException!
            if (iterator != null && selectedRowKey != null) {
                iterator.setCurrentRowWithKey(selectedRowKey);

                Row currentRow = iterator.getCurrentRow();
                Number empId = (Number) currentRow.getAttribute("EmployeeId");
                System.out.println("Selected Employee Id: " + empId);

                ViewObject linkEmpVO = getAm().getEmployeeVO1();
                ViewCriteria vc = linkEmpVO.getViewCriteriaManager().getViewCriteria("EmployeeVOCriteria");
                linkEmpVO.applyViewCriteria(vc);
                linkEmpVO.setNamedWhereClauseParam("bindEmpId", empId);
                linkEmpVO.executeQuery();
            } else {
                System.err.println("Iterator or selectedRowKey is null");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setSelectedRowKey(String selectedRowKey) {
        this.selectedRowKey = selectedRowKey;
    }

    public String getSelectedRowKey() {
        return selectedRowKey;
    }

    private DCIteratorBinding getIteratorBinding(String iteratorName) {
        BindingContainer bindings = BindingContext.getCurrent().getCurrentBindingsEntry();
        return (DCIteratorBinding) bindings.get(iteratorName);
    }
}
