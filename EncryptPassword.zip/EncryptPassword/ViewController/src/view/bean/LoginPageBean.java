package view.bean;

import java.nio.charset.StandardCharsets;

import java.security.Key;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import javax.el.ELContext;
import javax.el.ExpressionFactory;
import javax.el.ValueExpression;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import model.service.EncryptionAndDecryptionAMImpl;

import oracle.adf.view.rich.component.rich.input.RichInputText;

import oracle.jbo.Row;
import oracle.jbo.ViewObject;

public class LoginPageBean {
    private RichInputText USERNAME;
    private RichInputText PASSWORD;
    
    public LoginPageBean() {
    }
    public static Object evaluateEL(String el) {

           FacesContext facesContext = FacesContext.getCurrentInstance();
           ELContext elContext = facesContext.getELContext();
           ExpressionFactory ef = facesContext.getApplication().getExpressionFactory();
           ValueExpression exp = ef.createValueExpression(elContext, el, Object.class);

           return exp.getValue(elContext);
       }

       protected EncryptionAndDecryptionAMImpl getAm() {
           return (EncryptionAndDecryptionAMImpl) evaluateEL("#{data.EncryptionAndDecryptionAMDataControl.dataProvider}");
       }

    public void onClickLoginButtonAL(ActionEvent actionEvent) {
        // Add event code here...
        try {
           String username = USERNAME.getValue() != null ? USERNAME.getValue().toString() : "";
           String password = PASSWORD.getValue() != null ? PASSWORD.getValue().toString() : "";

           ViewObject loginVO = (ViewObject) getAm().getLoginDetailsQueryBasedVO1();
           
           loginVO.setNamedWhereClauseParam("bindUsername", username);
           loginVO.executeQuery();
           int countrow=(int)   loginVO.getEstimatedRowCount();
           System.out.println("Row count is------>"+loginVO.getEstimatedRowCount());
           
           System.out.println("---------------------->"+loginVO.getQuery());
           Row r = (Row) loginVO.first();
           System.out.println("----------------->"+loginVO.getCurrentRow());
           System.out.println("------------------------>"+loginVO.first());
           if(countrow>0){
           String uname = (String) r.getAttribute("Username");
           String Upassword = (String) r.getAttribute("PaswordHash");
           
           System.out.println("Entered Username ----------" +username);
           System.out.println("Entered Password -------->"+password);
            String encryptedPassword = encryptPassword(password);
            System.out.println("Encrypted Password------>"+encryptedPassword);
            
            

           if (uname.equals(username)  && Upassword.equals(encryptedPassword)) {
               FacesContext.getCurrentInstance().getApplication().getNavigationHandler()
                   .handleNavigation(FacesContext.getCurrentInstance(), null, "NextPage");
           } 
                       else {
                           FacesContext facesContext = FacesContext.getCurrentInstance();
                           FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                               "Invalid Username or Password",
                               "Invalid Username or Password");
                           facesContext.addMessage(null, message);
                       }
           }
           else{
               System.out.println("--------------------------------------------------------------------");
               FacesContext facesContext = FacesContext.getCurrentInstance();
               FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, 
                   "Invalid Username or Password", 
                   "Invalid Username or Password");
               facesContext.addMessage(null, message);
           }
       } catch (Exception e) {
            // TODO: Add catch code
            e.printStackTrace();
        }
        setUSERNAME(null);
        setPASSWORD(null);
    }
    
   
    // Encrypt the password using MD5
    private String encryptPassword(String password) {
        try {
            MessageDigest m = MessageDigest.getInstance("MD5");
            m.update(password.getBytes());
            byte[] bytes = m.digest();
            StringBuilder s = new StringBuilder();
            for (int i = 0; i < bytes.length; i++) {
                s.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
            }
            return s.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }
    

    public void setUSERNAME(RichInputText USERNAME) {
        this.USERNAME = USERNAME;
    }

    public RichInputText getUSERNAME() {
        return USERNAME;
    }

    public void setPASSWORD(RichInputText PASSWORD) {
        this.PASSWORD = PASSWORD;
    }

    public RichInputText getPASSWORD() {
        return PASSWORD;
    }
}