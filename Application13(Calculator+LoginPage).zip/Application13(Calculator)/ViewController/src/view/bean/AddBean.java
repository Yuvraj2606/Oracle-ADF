package view.bean;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import oracle.adf.view.rich.component.rich.RichPopup;
import oracle.adf.view.rich.component.rich.input.RichInputText;
import oracle.adf.view.rich.context.AdfFacesContext;

public class AddBean {
    private RichInputText bindinginput1;
    private RichInputText bindinginput2;
    Integer output1 = 0;
    private boolean inputDisabled = false;

     
    public void setOutput1(Integer output1) {
        this.output1 = output1;
    }

    public Integer getOutput1() {
        return output1;
    }
    public void setInputDisabled(boolean inputDisabled) {
        this.inputDisabled = inputDisabled;
    }

    public boolean isInputDisabled() {
        return inputDisabled;
    }  

    
    public AddBean() {
    }

    public void AddButtonAL(ActionEvent actionEvent) {
        // Add event code here...
        try {
            System.out.println("Binding Input 1---------->" + bindinginput1.getValue());
            System.out.println("Binding Input 2---------->" + bindinginput2.getValue());
            Integer a = Integer.parseInt((String) bindinginput1.getValue());
            Integer b = Integer.parseInt((String) bindinginput2.getValue());
            output1=a+b;
            System.out.println("Output is---------->"+output1);
        } catch (Exception e) {
            // TODO: Add catch code
            e.printStackTrace();
        }
        disableInputs();
    }
    public void SubtractButtonAL(ActionEvent actionEvent) {
        // Add event code here...
        try {
            System.out.println("Binding Input 1---------->" + bindinginput1.getValue());
            System.out.println("Binding Input 2---------->" + bindinginput2.getValue());
            Integer a = Integer.parseInt((String) bindinginput1.getValue());
            Integer b = Integer.parseInt((String) bindinginput2.getValue());
            if(a>=b){
                output1=a-b;
                System.out.println("Output is---------->"+output1);
            }
            else{
                System.out.println("input2 is not greater than input1");
                FacesMessage message = new FacesMessage("Input2 is not greater than Input1");   
                      message.setSeverity(FacesMessage.SEVERITY_ERROR);   
                      FacesContext fc = FacesContext.getCurrentInstance();   
                      fc.addMessage(null, message);
                output1 = 0;
            }
        } catch (Exception e) {
            // TODO: Add catch code
            e.printStackTrace();
        }
        disableInputs();
    }

    public void MultiplyButtonAL(ActionEvent actionEvent) {
        // Add event code here...
        try {
            System.out.println("Binding Input 1---------->" + bindinginput1.getValue());
            System.out.println("Binding Input 2---------->" + bindinginput2.getValue());
            Integer a = Integer.parseInt((String) bindinginput1.getValue());
            Integer b = Integer.parseInt((String) bindinginput2.getValue());
            output1=a*b;
            System.out.println("Output is---------->"+output1);
        } catch (Exception e) {
            // TODO: Add catch code
            e.printStackTrace();
        }
        disableInputs();
    }

    public void DivideButtonAL(ActionEvent actionEvent) {
        // Add event code here...
        try {
            System.out.println("Binding Input 1---------->" + bindinginput1.getValue());
            System.out.println("Binding Input 2---------->" + bindinginput2.getValue());
            Integer a = Integer.parseInt((String) bindinginput1.getValue());
            Integer b = Integer.parseInt((String) bindinginput2.getValue());
            if(b == 0){
                System.out.println("input 2 cannot be zero");
                FacesMessage message = new FacesMessage("input 2 cannot be zero");   
                      message.setSeverity(FacesMessage.SEVERITY_ERROR);   
                      FacesContext fc = FacesContext.getCurrentInstance();   
                      fc.addMessage(null, message);
                output1 = 0;
            }
            else{
                output1=a/b; 
                System.out.println("Output is---------->"+output1);
            }
            
            
        } catch (Exception e) {
            // TODO: Add catch code
            e.printStackTrace();
        }
        disableInputs();
    }
    public void ResetButtonAL(ActionEvent actionEvent) {
            // Add event code here...
            enableInputs();
            bindinginput1 =null;
            bindinginput2 =null;
            output1 = 0;
        }
    
    public void disableInputs() {
            inputDisabled = true; // 
        }
        // Reset input state for new entries
        public void enableInputs() {
            inputDisabled = false; // Enable inputs for editing
        }

    public void setBindinginput1(RichInputText bindinginput1) {
        this.bindinginput1 = bindinginput1;
    }

    public RichInputText getBindinginput1() {
        return bindinginput1;
    }

    public void setBindinginput2(RichInputText bindinginput2) {
        this.bindinginput2 = bindinginput2;
    }

    public RichInputText getBindinginput2() {
        return bindinginput2;
    }   
}
