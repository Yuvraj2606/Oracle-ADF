package view.bean;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import oracle.adf.view.rich.component.rich.input.RichInputText;

public class LoginBean {
    private RichInputText username;
    private RichInputText password;
    
    public LoginBean() {
    }

    public void onClickLoginButtonAL(ActionEvent actionEvent) {
        // Add event code here...
        try {
           String inputUsername = (String) username.getValue();
                      String inputPassword = (String) password.getValue();
                      System.out.println("Username -------->" + inputUsername);
                      System.out.println("Password -------->" + inputPassword);

                      if ("Calculator".equals(inputUsername) && "welcome1".equals(inputPassword)) {
                FacesContext.getCurrentInstance().getApplication().getNavigationHandler()
                    .handleNavigation(FacesContext.getCurrentInstance(), null, "callcalculator");
                }
                else{
                    System.out.println("Invalid username or password.");
                FacesContext facesContext = FacesContext.getCurrentInstance();
                FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, 
                    "Invalid Username or Password", 
                    "Invalid Username or Password");
                facesContext.addMessage(null, message);
                }
       } catch (Exception e) {
            // TODO: Add catch code
            e.printStackTrace();
        }
        
       setUsername(null); 
       setPassword(null);
    }

    public void setUsername(RichInputText username) {
        this.username = username;
    }

    public RichInputText getUsername() {
        return username;
    }

    public void setPassword(RichInputText password) {
        this.password = password;
    }

    public RichInputText getPassword() {
        return password;
    }
}
