package view.bean;

import java.nio.charset.StandardCharsets;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;

import java.sql.Timestamp;

import java.util.Base64;
import java.util.Date;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import javax.el.ELContext;
import javax.el.ExpressionFactory;
import javax.el.ValueExpression;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import model.service.PracTask5AMImpl;

import oracle.adf.view.rich.component.rich.input.RichInputText;

import oracle.jbo.Row;
import oracle.jbo.ViewCriteria;
import oracle.jbo.ViewObject;
import oracle.jbo.domain.Number;

public class LoginPageBean {
    private RichInputText USERNAME;
    private RichInputText PASSWORD;
    private static final String SECRET_KEY = "123456789";
    private static final String SALTVALUE = "abcdefg";
    private RichInputText USERID;
    private RichInputText CURRENTPASSWORD;
    private RichInputText NEWPASSWORD;
    public LoginPageBean() {
    }
    public static Object evaluateEL(String el) {

           FacesContext facesContext = FacesContext.getCurrentInstance();
           ELContext elContext = facesContext.getELContext();
           ExpressionFactory ef = facesContext.getApplication().getExpressionFactory();
           ValueExpression exp = ef.createValueExpression(elContext, el, Object.class);

           return exp.getValue(elContext);
       }

       protected PracTask5AMImpl getAm() {

           return (PracTask5AMImpl) evaluateEL("#{data.PracTask5AMDataControl.dataProvider}");
       }
    private String decrypt(String strToDecrypt) {
        try {
            byte[] iv = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
            IvParameterSpec ivspec = new IvParameterSpec(iv);
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            KeySpec spec = new PBEKeySpec(SECRET_KEY.toCharArray(), SALTVALUE.getBytes(), 65536, 256);
            SecretKey tmp = factory.generateSecret(spec);
            SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
            cipher.init(Cipher.DECRYPT_MODE, secretKey, ivspec);
            return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
        } catch (InvalidAlgorithmParameterException | InvalidKeyException | NoSuchAlgorithmException | InvalidKeySpecException | BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException e) {
            System.out.println("Error occurred during decryption: " + e.toString());
        }
        return null;
    }
    private String encrypt(String strToEncrypt) throws Exception {
        try {
            byte[] iv = new byte[16]; // Initialization vector with 16 bytes
            IvParameterSpec ivspec = new IvParameterSpec(iv);

            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            KeySpec spec = new PBEKeySpec(SECRET_KEY.toCharArray(), SALTVALUE.getBytes(), 65536, 256);
            SecretKey tmp = factory.generateSecret(spec);
            SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivspec);

            return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            System.out.println("Error occurred during encryption: " + e.toString());
            throw e; // Re-throwing the exception after logging
        }
    }

    public void onClickLoginButtonAL(ActionEvent actionEvent) {
        // Add event code here...
        try {
           String username = USERNAME.getValue() != null ? USERNAME.getValue().toString() : "";
           String password = PASSWORD.getValue() != null ? PASSWORD.getValue().toString() : "";
            
           ViewObject loginVO = (ViewObject) getAm().getUsersDataQueryBasedVO1();
           loginVO.setNamedWhereClauseParam("bindUsername", username);
           loginVO.executeQuery();
           int countrow = (int) loginVO.getEstimatedRowCount();
           System.out.println("Row count is------>" + loginVO.getEstimatedRowCount());

           System.out.println("---------------------->" + loginVO.getQuery());
           Row r = (Row) loginVO.first();
           System.out.println("----------------->" + loginVO.getCurrentRow());
           System.out.println("------------------------>" + loginVO.first());
            
           if (countrow > 0) {
               String Uname = (String) r.getAttribute("UserName");
               String Upassword = (String) r.getAttribute("Password");
               Date UPasswordValidUpto = (Date) r.getAttribute("PasswordValidUpto");
               
               String decryptedPassword = decrypt(Upassword);

               if (Uname.equals(username.toUpperCase()) && decryptedPassword.equals(password)) {
                   // Check if the current system date is less than or equal to UPasswordValidUpto
                   Date currentDate = new Date();
                   if (currentDate.compareTo(UPasswordValidUpto) <= 0) {
                       // Navigate to the desired page
                       FacesContext.getCurrentInstance().getApplication().getNavigationHandler()
                           .handleNavigation(FacesContext.getCurrentInstance(), null, "ViewData");
                   } else {
                       // Password validity has expired
                       FacesContext facesContext = FacesContext.getCurrentInstance();
                       FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                           "Password Expired",
                           "Your password is no longer valid. Please contact support.");
                       facesContext.addMessage(null, message);
                   }
               } else {
                   // Username or password is incorrect
                   FacesContext facesContext = FacesContext.getCurrentInstance();
                   FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                       "Invalid Username or Password",
                       "Invalid Username or Password");
                   facesContext.addMessage(null, message);
               }
           } else {
               // Username does not exist
               FacesContext facesContext = FacesContext.getCurrentInstance();
               FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                   "Invalid Username or Password",
                   "Invalid Username or Password");
               facesContext.addMessage(null, message);
           }
       } catch (Exception e) {
            // TODO: Add catch code
            e.printStackTrace();
        }
        setUSERNAME(null);
        setPASSWORD(null);   
    }

    public void onClickSaveButtonAL(ActionEvent actionEvent) throws Exception {
        // Add event code here...
        String userIdStr = USERID.getValue() != null ? USERID.getValue().toString() : null;
        String currentPassword = CURRENTPASSWORD.getValue() != null ? CURRENTPASSWORD.getValue().toString() : "";
        String newPassword = NEWPASSWORD.getValue() != null ? NEWPASSWORD.getValue().toString() : "";
        
        Integer userId = userIdStr != null ? Integer.valueOf(userIdStr) : null;
        
        System.out.println("Entered UserId----------->"+userId);
        System.out.println("Enter Current Password ------->"+currentPassword);
        System.out.println("Enter New Password------>"+newPassword);
        String encryptnewPassword = encrypt(newPassword);
        
        System.out.println("Encrypted Password------->"+encryptnewPassword);

        ViewObject userVO = (ViewObject) getAm().getUsersIDVO1();
            ViewCriteria vc = userVO.getViewCriteriaManager().getViewCriteria("UsersIDVOCriteria");
                  userVO.applyViewCriteria(vc);
                 userVO.setNamedWhereClauseParam("bindUserId", userId);
                 userVO.executeQuery();
        int countrow = (int) userVO.getEstimatedRowCount();
        System.out.println("Row count is------>" + userVO.getEstimatedRowCount());    
            Row r = (Row) userVO.first();
            if (countrow > 0) {
                Number Uid = (Number) r.getAttribute("UserId");
                System.out.println("UserId ------>"+Uid);
                 
                if (Uid.equals(userId)){
                    
                        
                        r.setAttribute("Password", encryptnewPassword);
                                 
                                   

                                   // Update PasswordValidUpto attribute to current system date plus 2 days
                                   Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
                                   long twoDaysInMillis = 2 * 24 * 60 * 60 * 1000; // 2 days in milliseconds
                                   Timestamp passwordValidUpto = new Timestamp(currentTimestamp.getTime() + twoDaysInMillis);
                                   r.setAttribute("PasswordValidUpto", passwordValidUpto);
                                   r.setAttribute("LastUpdatedDate", currentTimestamp);
                                   // Commit changes to database
                                   getAm().getDBTransaction().commit();
                                   FacesContext facesContext = FacesContext.getCurrentInstance();
                                   FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
                                       "Password updated successfully.",
                                       "Password updated successfully.");
                                   facesContext.addMessage(null, message);
                               } else {
                                   FacesContext facesContext = FacesContext.getCurrentInstance();
                                   FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                       "Invalid User ID.",
                                       "Invalid User ID.");
                                   facesContext.addMessage(null, message);
                               }
                    }
            
    }

    public void setUSERNAME(RichInputText USERNAME) {
        this.USERNAME = USERNAME;
    }

    public RichInputText getUSERNAME() {
        return USERNAME;
    }

    public void setPASSWORD(RichInputText PASSWORD) {
        this.PASSWORD = PASSWORD;
    }

    public RichInputText getPASSWORD() {
        return PASSWORD;
    }

    public void setUSERID(RichInputText USERID) {
        this.USERID = USERID;
    }

    public RichInputText getUSERID() {
        return USERID;
    }

    public void setCURRENTPASSWORD(RichInputText CURRENTPASSWORD) {
        this.CURRENTPASSWORD = CURRENTPASSWORD;
    }

    public RichInputText getCURRENTPASSWORD() {
        return CURRENTPASSWORD;
    }

    public void setNEWPASSWORD(RichInputText NEWPASSWORD) {
        this.NEWPASSWORD = NEWPASSWORD;
    }

    public RichInputText getNEWPASSWORD() {
        return NEWPASSWORD;
    }
}
