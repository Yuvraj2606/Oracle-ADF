package view.bean;

import java.nio.charset.StandardCharsets;

import java.security.spec.KeySpec;

import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import oracle.adf.model.AttributeBinding;
import oracle.adf.model.BindingContext;
import oracle.adf.model.OperationBinding;
import oracle.adf.model.binding.DCBindingContainer;

public class InsertPageBean {
    private static final String SECRET_KEY = "123456789"; // Ensure this is securely stored
    private static final String SALTVALUE = "abcdefg"; // Ensure this is securely stored
    public InsertPageBean() {
    }

    public void onClickSaveButtonAL(ActionEvent actionEvent) {
        try {
            // Get the binding container
            DCBindingContainer bindings = getBindings();

            // Get the password input value
            AttributeBinding passwordAttr = (AttributeBinding) bindings.getControlBinding("Password");
            String password = (String) passwordAttr.getInputValue();

            // Encrypt the password using AES
            String encryptedPassword = encrypt(password);

            // Set the encrypted password as the new input value
            passwordAttr.setInputValue(encryptedPassword);
            OperationBinding commit = (OperationBinding) bindings.getOperationBinding("Commit");
            if (commit != null) {
                commit.execute();

                // Check for errors after executing the commit operation
                if (!commit.getErrors().isEmpty()) {
                    // If there are errors, show an error message
                    FacesContext facesContext = FacesContext.getCurrentInstance();
                    facesContext.addMessage(null, new javax.faces.application.FacesMessage(
                        javax.faces.application.FacesMessage.SEVERITY_ERROR,
                        "Save failed",
                        "There was an issue saving the data."
                    ));
                } else {
                    // If there are no errors, show a success message
                    FacesContext facesContext = FacesContext.getCurrentInstance();
                    facesContext.addMessage(null, new javax.faces.application.FacesMessage(
                        javax.faces.application.FacesMessage.SEVERITY_INFO,
                        "Save successful",
                        "Password Saved successfully."
                    ));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        // Add event code here...
    }
    private DCBindingContainer getBindings() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        BindingContext bindingContext = BindingContext.getCurrent();
        return (DCBindingContainer) bindingContext.getCurrentBindingsEntry();
    }

    // Method to encrypt the password using AES
    private String encrypt(String strToEncrypt) throws Exception {
        try {
            byte[] iv = new byte[16]; // Initialization vector with 16 bytes
            IvParameterSpec ivspec = new IvParameterSpec(iv);

            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            KeySpec spec = new PBEKeySpec(SECRET_KEY.toCharArray(), SALTVALUE.getBytes(), 65536, 256);
            SecretKey tmp = factory.generateSecret(spec);
            SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivspec);

            return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            System.out.println("Error occurred during encryption: " + e.toString());
            throw e; // Re-throwing the exception after logging
        }
    }
}
